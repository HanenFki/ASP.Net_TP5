﻿namespace MyModels
{
    public enum Gender
    {
        Male,
        Female
    }
}
